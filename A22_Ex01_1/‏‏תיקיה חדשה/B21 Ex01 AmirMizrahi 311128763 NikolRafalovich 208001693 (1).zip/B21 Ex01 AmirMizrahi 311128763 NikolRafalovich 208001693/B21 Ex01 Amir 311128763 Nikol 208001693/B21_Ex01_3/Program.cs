﻿using System;
using B21_Ex01_2;

namespace B21_Ex01_3
{
    public class Program
    {
        public static void Main()
        {
            runProgram();
        }

        private static void runProgram()
        {
            Console.WriteLine("Please enter the level of the sand clock.");
            string      sandClockLevelStr = Console.ReadLine();
            while (!isInteger(sandClockLevelStr))
            {
                Console.WriteLine("Invalid input. Please enter a number.");
                sandClockLevelStr = Console.ReadLine();
            }
            int         sandClockLevel = int.Parse(sandClockLevelStr);
            if (sandClockLevel % 2 == 0)
            {
                ++sandClockLevel;
            }

            B21_Ex01_2.Program.PrintSandClock(sandClockLevel, sandClockLevel);
        }

        private static bool isInteger(string i_stringToCheck)
        {
            bool        isInt = true;
            for(int i=0; isInt && i < i_stringToCheck.Length; ++i)
            {
                if((i_stringToCheck[i] < '0') || (i_stringToCheck[i] > '9'))
                {
                    isInt = !isInt;
                }
            }

            return isInt;
        }
    }
}
