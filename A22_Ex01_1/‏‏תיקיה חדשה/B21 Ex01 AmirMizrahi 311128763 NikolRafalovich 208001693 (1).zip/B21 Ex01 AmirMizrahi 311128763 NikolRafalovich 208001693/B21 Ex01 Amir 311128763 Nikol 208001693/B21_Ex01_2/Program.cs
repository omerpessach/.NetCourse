﻿namespace B21_Ex01_2
{
    using System;
    public class Program
    {
        public static void Main()
        {
            PrintSandClock(3, 3);
        }

        public static void PrintSandClock(int i_height,int i_currentLevelOfTheClock)
        {
            if (i_currentLevelOfTheClock == 1)
            {
                printXNumberOfGivenChar(i_height - 1, ' ');
                Console.WriteLine('*');
            }
            else
            {
                printOneLevelOfSandClock(i_height, i_currentLevelOfTheClock);
                PrintSandClock(i_height, i_currentLevelOfTheClock - 1);
                printOneLevelOfSandClock(i_height, i_currentLevelOfTheClock);
            }
        }

        private static void printXNumberOfGivenChar(int i_numberOfSpacesToPrint,char i_charToPrint)
        {
            for (int i = 0; i < i_numberOfSpacesToPrint; ++i)
            {
                Console.Write(i_charToPrint);
            }
        }

        private static void printOneLevelOfSandClock(int i_height, int i_currentLevelOfTheClock)
        {
            printXNumberOfGivenChar(i_height - i_currentLevelOfTheClock, ' ');
            printXNumberOfGivenChar(2 * i_currentLevelOfTheClock - 1, '*');
            Console.WriteLine();
        }
    }
}
