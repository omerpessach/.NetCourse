﻿using System;

namespace B21_Ex01_4
{
    class Program
    {
        public static void Main()
        {
            runProgram();   
        }

        private static void runProgram()
        {
            string      strToPrint;
            int         theValueOfTheString = 0;
            bool        isTheInputANumber = true;
            Console.WriteLine(@"Please enter a string.
The length of the string should be 10 chars.
The string should contain only number of letters but not combined.");
            string      inputStr = Console.ReadLine();
            while (!inputCheck(inputStr, ref theValueOfTheString, ref isTheInputANumber))
            {
                Console.WriteLine("The input is invalid. Please enter a valid string.");
                inputStr = Console.ReadLine();
            }
            strToPrint = string.Format("Is the string a Palindrome? {0}", isPalindrome(inputStr, 0, inputStr.Length - 1) ? "YES" : "NO");
            Console.WriteLine(strToPrint);
            if (isTheInputANumber)
            {
                strToPrint = string.Format("Is the input divides by 4? {0}", theValueOfTheString % 4 == 0 ? "YES" : "NO");
                Console.WriteLine(strToPrint);
            }
            else//the string contains only letters
            {
                strToPrint = string.Format("The number of upper case letters on the string is: {0}", countNumberOfUpperCase(inputStr));
                Console.WriteLine(strToPrint);
            }
        }

        private static bool inputCheck(string io_StrToCheck, ref int o_ResultOfParse, ref bool isANumber)
        {
            const bool      v_isANumber = true;
            bool            isTheStrInLegalFormat = true;
            if (io_StrToCheck.Length != 10)
                isTheStrInLegalFormat = !isTheStrInLegalFormat;
            else if (!int.TryParse(io_StrToCheck,out o_ResultOfParse))
            {
                isANumber = !v_isANumber;
                for (int i = 0; i < io_StrToCheck.Length; ++i)
                {
                    if (!((((io_StrToCheck[i] >= 'A') && (io_StrToCheck[i] <= 'Z'))) || (((io_StrToCheck[i] >= 'a') && (io_StrToCheck[i] <= 'z')))))
                    {
                        isTheStrInLegalFormat = !isTheStrInLegalFormat;
                        break;
                    }
                }
            }
            else
            {
                isANumber = v_isANumber;
            }

            return isTheStrInLegalFormat;
        }

        private static bool isPalindrome(string io_StrToCheck,int i_start, int i_end)
        {
            const bool      v_theStrIsAPolindrom = true;
            bool            isPolindormVariable = true;
            if(!((i_start == i_end) || (i_end == i_start+1) ))
            {
                if(io_StrToCheck[i_start] == io_StrToCheck[i_end])
                {
                    isPolindormVariable=isPalindrome(io_StrToCheck, i_start+1,i_end - 1);
                }
                else
                {
                    isPolindormVariable = !v_theStrIsAPolindrom;
                }
            }

            return isPolindormVariable;
        }

        private static int countNumberOfUpperCase(string i_strToCountIn)
        {
            int             counterOfUpperCase = 0;
            for(int i=0; i < i_strToCountIn.Length; ++i)
            {
                if((i_strToCountIn[i] >= 'A') && (i_strToCountIn[i] <= 'Z'))
                {
                    ++counterOfUpperCase;
                }
            }

            return counterOfUpperCase;
        }
    }
}