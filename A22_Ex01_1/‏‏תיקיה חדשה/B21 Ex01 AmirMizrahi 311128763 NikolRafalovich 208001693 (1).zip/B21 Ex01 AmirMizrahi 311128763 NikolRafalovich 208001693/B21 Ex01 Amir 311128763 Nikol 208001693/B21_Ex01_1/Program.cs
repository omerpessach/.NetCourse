﻿namespace B21_Ex01_1
{
    using System;
    using System.Text;
    public class Program
    {
        public static void Main()
        {
            runProgram();
        }

        private static void runProgram()
        {
            StringBuilder   strToPrint = new StringBuilder();
            int             countNumberOfAllOnes = 0;
            int[]           arrOfNumberInDecimal = new int[3];
            int             countNumberOfPowerOf2 = 0;
            int             countDescendingNumbers = 0;
            Console.WriteLine(
                @"Please enter three binary numbers.
Each number contains seven digits.
end with enter.");
            for (int i = 0; i < 3; ++i)
            {
                int         numOfOnes = 0;
                string numberInBinary = Console.ReadLine();
                while (numberInBinary.Length != 7 || !isAllCharAreNumbers(numberInBinary))
                {
                    Console.WriteLine("The number you entered is not valid. Please enter a legal number.");
                    numberInBinary = Console.ReadLine();
                }
                numOfOnes = countNumOfOnesInBinaryNumber(numberInBinary);
                countNumberOfAllOnes += numOfOnes;
                if (numOfOnes == 1)
                {
                    ++countNumberOfPowerOf2;
                }
                arrOfNumberInDecimal[i] = convertNumberFromBinaryToDecimal(numberInBinary);
                if (isDescendingNumber(arrOfNumberInDecimal[i]))
                {
                    ++countDescendingNumbers;
                }
            }

            printProgramOutput(ref arrOfNumberInDecimal, ref strToPrint, countNumberOfPowerOf2, countNumberOfAllOnes, countDescendingNumbers);
        }

        private static bool isAllCharAreNumbers(string i_stringToCheck)
        {
            const bool      v_IsTheNumberValid = true;
            for (int i = 0; i < i_stringToCheck.Length; ++i)
            {
                if ((i_stringToCheck[i] < '0') || (i_stringToCheck[i] > '1'))
                {
                    return !v_IsTheNumberValid;
                }
            }

            return v_IsTheNumberValid;
        }

        private static int countNumOfOnesInBinaryNumber(string i_stringToCountIn)
        {
            int         counterOfOnes = 0;
            for (int i = 0; i < 7; ++i)
            {
                if (i_stringToCountIn[i] == '1')
                {
                    ++counterOfOnes;
                }
            }

            return counterOfOnes;
        }

        private static int convertNumberFromBinaryToDecimal(string i_strToConvert)
        {
            int         convertedNumber = 0;
            for (int i = 0; i < i_strToConvert.Length; ++i)
            {
                if (i_strToConvert[i] == '1')
                {
                    convertedNumber += (int)Math.Pow(2, 7 - i - 1);
                }
            }

            return convertedNumber;
        }

        private static bool isDescendingNumber(int i_numberToCheck)
        {
            const bool  v_IsTheNumberValid = true;
            int previousDigit;
            do
            {
                previousDigit = i_numberToCheck / 10;
                i_numberToCheck %= 10;
                if (previousDigit <= i_numberToCheck / 10)
                {
                    return !v_IsTheNumberValid;
                }
            } while (i_numberToCheck > 0);

            return v_IsTheNumberValid;
        }

        private static void arrangeArrayByValue(int[] io_arrToArrange)
        {
            for (int i = 0; i < io_arrToArrange.Length - 1; ++i)
                for (int j = 0; j < io_arrToArrange.Length - i - 1; j++)
                    if (io_arrToArrange[j] > io_arrToArrange[j + 1])
                    {
                        // swap temp and arr[i]
                        int temporaryInt = io_arrToArrange[j];
                        io_arrToArrange[j] = io_arrToArrange[j + 1];
                        io_arrToArrange[j + 1] = temporaryInt;
                    }
        }
        private static void printProgramOutput(ref int[] i_arrOfNumberInDecimal, ref StringBuilder i_strToPrint,
                                int i_countNumberOfPowerOf2, int i_countNumberOfAllOnes, int i_countDescendingNumbers)
        {
            string stringToPrintValuesInDecimal = string.Format(@"The numbers in decimal base are: {0},{1},{2}.
", i_arrOfNumberInDecimal[0].ToString(), i_arrOfNumberInDecimal[1].ToString(), i_arrOfNumberInDecimal[2].ToString());
            i_strToPrint.Append(stringToPrintValuesInDecimal);
            arrangeArrayByValue(i_arrOfNumberInDecimal);
            float averageNumberOfOnes = i_countNumberOfAllOnes / 3.0f;
            float averageNumberOfZeros = (21 - i_countNumberOfAllOnes) / 3.0f;
            i_strToPrint.Append("" +
                "The average number of 1 is: " + averageNumberOfOnes);
            i_strToPrint.Append(@"
The average number of 0 is: " + averageNumberOfZeros);
            i_strToPrint.Append(@"
There are " + i_countNumberOfPowerOf2 + " numbers that are a power of 2.");
            i_strToPrint.Append(@"
There are " + i_countDescendingNumbers + " numbers that have descending digits.");
            i_strToPrint.Append(@"
The heights number is: " + i_arrOfNumberInDecimal[2] + " and the lowest number is: " + i_arrOfNumberInDecimal[0]);
            Console.WriteLine(i_strToPrint);
        }
    }
}