﻿using System;

namespace B21_Ex01_6
{
    class Program
    {
        public static void Main()
        {
            runProgram();
        }

        private static void runProgram()
        {
            char        maxDigit = '0', minDigit = '0';
            Console.WriteLine("Please enter a 6 digit positive number.");
            string      digitsString = Console.ReadLine();
            while (!isLegalNumber(digitsString))
            {
                Console.WriteLine("Invalid input. please enter a valid input.");
                digitsString = Console.ReadLine();
            }

            findMinAndMaxDigits(digitsString, ref maxDigit, ref minDigit);
            string      strToPrint = string.Format(@"The max digit is: {0}.
The min digit is: {1}.
The number of digits that divides by three is: {2}.
The number of digits that bigger than the units digit is: {3}."
, maxDigit, minDigit, countDigitsThatDivideByThree(digitsString), countDigutsThatBiggerThanUnits(digitsString));
            Console.WriteLine(strToPrint);
        }

        private static bool isLegalNumber(string i_strTocheck)
        {
            bool        isLegalNumberVariable = true;
            if(i_strTocheck.Length != 6)
            {
                isLegalNumberVariable = !isLegalNumberVariable;
            }
            else for(int i=0; i < i_strTocheck.Length && isLegalNumberVariable; ++i)
            {
                if((i_strTocheck[i] < '0') || (i_strTocheck[i] > '9'))
                {
                    isLegalNumberVariable = !isLegalNumberVariable;
                }
            }

            return isLegalNumberVariable;
        }

        private static void findMinAndMaxDigits(string i_strToFindIn, ref char io_max, ref char io_min)
        {
            io_max = io_min = i_strToFindIn[0];
            for(int i=0; i < i_strToFindIn.Length; ++i)
            {
                if(i_strToFindIn[i] < io_min)
                {
                    io_min = i_strToFindIn[i];
                }
                else if(i_strToFindIn[i] > io_max)
                {
                    io_max = i_strToFindIn[i];
                }
            }
        }

        private static int countDigitsThatDivideByThree(string i_strToCountIn)
        {
            int         countDivBy3 = 0;
            for(int i=0; i < i_strToCountIn.Length; ++i)
            {
                if((int)i_strToCountIn[i] % 3 == 0)
                {
                    ++countDivBy3;
                }
            }

            return countDivBy3;
        }

        private static int countDigutsThatBiggerThanUnits(string i_strToCountIn)
        {
            int         countBigerThanUnits = 0;
            for(int i=0; i < i_strToCountIn.Length-1; ++i)
            {
                if(i_strToCountIn[i] > i_strToCountIn[i_strToCountIn.Length-1])
                {
                    ++countBigerThanUnits;
                }
            }

            return countBigerThanUnits;
        }
    }
}