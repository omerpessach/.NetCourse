﻿namespace Ex03.GarageLogic.Enums
{
    public enum eLicenseType
    {
        A = 1,
        AA,
        A2,
        B,
    }
}
