﻿namespace Ex03.GarageLogic.Enums
{
    public enum eFuelType
    {
        Octan98,
        Octan96,
        Octan95,
        Soler,
    }
}
