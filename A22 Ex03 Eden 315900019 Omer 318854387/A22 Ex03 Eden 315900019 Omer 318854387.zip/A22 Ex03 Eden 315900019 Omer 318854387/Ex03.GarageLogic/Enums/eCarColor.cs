﻿namespace Ex03.GarageLogic.Enums
{
    public enum eCarColor
    {
        Red = 1,
        White,
        Black,
        Blue,
    }
}
