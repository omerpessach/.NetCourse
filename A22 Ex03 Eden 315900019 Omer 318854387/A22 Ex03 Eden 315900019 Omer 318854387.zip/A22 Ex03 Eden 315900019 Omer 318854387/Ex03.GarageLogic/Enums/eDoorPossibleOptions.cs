﻿namespace Ex03.GarageLogic.Enums
{
    public enum eDoorPossibleOptions
    {
        Two = 2,
        Three,
        Four,
        Five,
    }
}
