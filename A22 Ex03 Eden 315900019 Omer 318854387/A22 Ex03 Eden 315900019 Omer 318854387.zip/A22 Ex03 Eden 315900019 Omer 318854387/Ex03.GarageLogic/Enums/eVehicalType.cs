﻿namespace Ex03.GarageLogic.Enums
{
    public enum eVehicalType
    {
        FuelCar = 1,
        ElectircCar,
        FuelMotocycle,
        ElectricMotocycle,
        Truck,
    }
}
