﻿namespace Ex03.GarageLogic.Enums
{
    public enum eVehicalStatus
    {
        InRepair,
        Fixed,
        Paid,
    }
}
