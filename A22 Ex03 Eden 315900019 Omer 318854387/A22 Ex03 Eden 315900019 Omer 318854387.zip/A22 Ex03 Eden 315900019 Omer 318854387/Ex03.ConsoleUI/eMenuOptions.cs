﻿namespace Ex03.ConsoleUI
{
    public enum eMenuOptions
    {
        AddNewVehical = 1,
        GetLicensesIDsFilterByStatus,
        ChangeVehicalStatus,
        FillAirToMax,
        FuelCar,
        ChargeCar,
        GetAllVehicalDetails,
        Exit
    }
}